// ============================================================
//  DATABASE MIGRATION RUNNER
//  Inasoma migration.sql na kuiendesha kwenye DATABASE_URL
//  Run: npm run migrate
// ============================================================
require('dotenv').config();
const fs = require('fs');
const path = require('path');

async function migrate() {
  if (!process.env.DATABASE_URL) {
    console.error('❌ DATABASE_URL haipo kwenye .env');
    process.exit(1);
  }

  const isNeon = process.env.DATABASE_URL.includes('neon.tech');
  let Pool, poolConfig;

  if (isNeon) {
    // Neon serverless driver - hutumia WebSocket/HTTPS badala ya TCP ya
    // moja kwa moja, kuepuka ETIMEDOUT kwenye mitandao inayozuia port 5432
    const neonServerless = require('@neondatabase/serverless');
    neonServerless.neonConfig.webSocketConstructor = require('ws');
    Pool = neonServerless.Pool;
    poolConfig = { connectionString: process.env.DATABASE_URL };
  } else {
    Pool = require('pg').Pool;
    poolConfig = {
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    };
  }

  const pool = new Pool(poolConfig);

  try {
    const sqlPath = path.join(__dirname, 'migration.sql');
    const sql = fs.readFileSync(sqlPath, 'utf8');

    console.log('⏳ Inaendesha migration...');
    await pool.query(sql);
    console.log('✅ Migration imekamilika kikamilifu! Majedwali yote yameundwa.');
  } catch (err) {
    console.error('❌ Migration imeshindwa:', err);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

migrate();
